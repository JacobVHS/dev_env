# Development Environment Collection

This collection contains Ansible roles to deploy configurations and templates for my Linux and MACOS workflows.

## Installation

```
ansible-galaxy install jacobvhs.unix_conf_management
```
